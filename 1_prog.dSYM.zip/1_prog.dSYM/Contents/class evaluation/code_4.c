#include<stdio.h>
int main()
{
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    if(num <= 100 && num >= 90)
    {
        printf("A grade\n"); 
    }
    else if(num < 90 && num >= 80)
    {
        printf("B grade\n");
    }
    else if(num < 80 && num >= 70)
    {
        printf("C grade\n");  
    }
    else if(num < 70 && num >= 60)
    {
        printf("D grade\n");  
    }
    else if(num < 60 && num >= 50)  
    {
        printf("E grade\n");  
    }
    else
    {
        printf("Fail\n");  
    }   
    return 0;
}
