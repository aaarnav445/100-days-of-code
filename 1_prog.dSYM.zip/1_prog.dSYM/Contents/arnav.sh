#!/bin/bash

#Define an array 
numbers=(5 2 8 1 9 3 7 4 6)

echo "original aray: ${numbers[@]}"

#Bubble sort implementation
n=${#numbers[@]}
for ((i = 0; i < n-1; i++)); do
for ((j = 0; j < n-i-1; j++)); do
if [ ${numbers[j]} -gt ${numbers[$((j+1))]} ]; then
# Swap elements
temp=${numbers[j]}
number[$j]=${numbers[$((j+i))]}
numbers[$((j+i))]=$temp
fi 
done
done
echo "sorted array: ${numbers[@]}"
