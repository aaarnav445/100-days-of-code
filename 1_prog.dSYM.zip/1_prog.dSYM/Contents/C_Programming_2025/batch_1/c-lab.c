#include<stdio.h>
int main()
{
int a=4,b=5;
printf("%d",a+b);
return 0;
}
