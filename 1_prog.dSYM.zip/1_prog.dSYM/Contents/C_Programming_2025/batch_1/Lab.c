#include<stdio.h>
int main(){
int sap_id=3035;
int sod;
sod=sap_id%10;
sap_id=sap_id/10;
sod=(sap_%10)+sod;
sap_id=sapid/10;
sod=(sap_id%10)+sod;
sap_id=sap_id/10;
sod=(sap_id%10)+sod;
sap_id=sap_id/10;
if(sod%2=0){
printf("even");
}
else{
printf('odd");
}
return 0;
}




