#!/bin/bash
#Declare an array
my_array=( alpha whiskey bravo charlie )
echo "original array: ${my_array[@]}"

#sort the array lexicographically
sorted_array=($(for element in "${my_array[@]}"; do echo "$element"; done | sort))
echo "sorted array (lexicographically): ${sorted_array[@]}"
