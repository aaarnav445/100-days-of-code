#include<stdio.h>
int main()
{
    int a;
    a=-5;
    if(a>0)
    {
        printf("Positive");
    }
    else if(a<0)
    {
        printf("Negative");
    }
    else
    {
        printf("Zero");
    }
    int b;
    b = 0;
    if(b>0)
    {
        printf("Positive");
    }
    else if (b<0)
    {
        printf("Negative");
    }
    else
    {
        printf("Zero");
    }
    return 0;
}