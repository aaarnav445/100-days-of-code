

#include <stdio.h>
/*This program accepts two integers as inputs and computes the sum . It then prints the two integers and the sum*/
int main()
{
    int a;
    int b;
    int sum;
    printf("Enter first integers: ");
    scanf("%d", &a);
    printf("Enter second integers: ");
    scanf("%d", &b);
    sum = a + b;
    printf("Sum of %d and %d is: %d\n", a, b, sum); 
    return 0;
}